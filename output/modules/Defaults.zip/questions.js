

test.AddQuestion( new Question ("com.scorm.OpenAT.interactions.Defaults_1",
    "True or False: Most devices/systems/services maximize security by default?", 
    QUESTION_TYPE_TF,
    null,
    "False",
    "obj_Defaults")
    );      

test.AddQuestion( new Question ("com.scorm.OpenAT.interactions.Defaults_2",
    "Attackers can conduct a Google search and frequently find the default credentials to your devices?", 
    QUESTION_TYPE_TF,
    null,
    "True",
    "obj_Defaults")
    );      

test.AddQuestion( new Question ("com.scorm.OpenAT.interactions.Defaults_3",
    "You should enable as many services and features as possible to get the most out of your services, systems, and devices?", 
    QUESTION_TYPE_TF,
    null,
    "False",
    "obj_Defaults")
    );      



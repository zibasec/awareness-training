

test.AddQuestion( new Question ("com.scorm.ZibaSec.interactions.Social-Engineering-101_1",
    "Social Engineering is not very common.", 
    QUESTION_TYPE_TF,
    null,
    "False",
    "obj_Social-Engineering-101")
    );      

test.AddQuestion( new Question ("com.scorm.ZibaSec.interactions.Social-Engineering-101_2",
    "Which of the following concepts is best described by 'following someone into a secure area'?", 
    QUESTION_TYPE_CHOICE, 
    new Array("Tailgating","Smishing","Baiting"),
    "Tailgating",
    "obj_Social-Engineering-101")
    );      

test.AddQuestion( new Question ("com.scorm.ZibaSec.interactions.Social-Engineering-101_3",
    "True or False: You should plug in a USB thumb drive you found in the parking lot.", 
    QUESTION_TYPE_TF,
    null,
    "False",
    "obj_Social-Engineering-101")
    );      



test.AddQuestion( new Question ("com.scorm.ZibaSec.interactions.Social-Engineering-101_4",
    "Which of the Key Principles is most like 'returning the favor'?", 
    QUESTION_TYPE_CHOICE, 
    new Array("Reciprocity","Commitment","Social Proof","Obeying Authority","Likability","Scarcity","Unity"),
    "Reciprocity",
    "obj_Social-Engineering-101")
    );      

test.AddQuestion( new Question ("com.scorm.ZibaSec.interactions.Social-Engineering-101_5",
    "Authority figures can be explicitly trusted.", 
    QUESTION_TYPE_TF,
    null,
    "False",
    "obj_Social-Engineering-101")
    );      



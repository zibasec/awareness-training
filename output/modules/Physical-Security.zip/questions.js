

test.AddQuestion( new Question ("com.scorm.ZibaSec.interactions.Physical-Security_1",
    "Physical security does *NOT* help mitigate which of these issues:", 
    QUESTION_TYPE_CHOICE, 
    new Array("Espionage","Theft","Loss","Phishing Emails"),
    "Phishing Emails",
    "obj_Physical-Security")
    );      

test.AddQuestion( new Question ("com.scorm.ZibaSec.interactions.Physical-Security_2",
    "True or False: Physical security is not as important as digital security?", 
    QUESTION_TYPE_TF,
    null,
    "False",
    "obj_Physical-Security")
    );      

test.AddQuestion( new Question ("com.scorm.ZibaSec.interactions.Physical-Security_3",
    "True or False: You should plug in a USB stick you found in the parking lot?", 
    QUESTION_TYPE_TF,
    null,
    "False",
    "obj_Physical-Security")
    );      



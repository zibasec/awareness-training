

test.AddQuestion( new Question ("com.scorm.OpenAT.interactions.Day-to-Day_1",
    "Updating software isn't important.", 
    QUESTION_TYPE_TF,
    null,
    "False",
    "obj_Day-to-Day")
    );      

test.AddQuestion( new Question ("com.scorm.OpenAT.interactions.Day-to-Day_2",
    "All social media games are secure.", 
    QUESTION_TYPE_TF,
    null,
    "False",
    "obj_Day-to-Day")
    );      

test.AddQuestion( new Question ("com.scorm.OpenAT.interactions.Day-to-Day_3",
    "Which software can you safely disable?", 
    QUESTION_TYPE_CHOICE, 
    new Array("Antivirus","Security Frameworks","Auto Updater","None of the above."),
    "None of the above.",
    "obj_Day-to-Day")
    );      



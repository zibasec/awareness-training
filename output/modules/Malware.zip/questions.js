

test.AddQuestion( new Question ("com.scorm.ZibaSec.interactions.Malware_1",
    "True or False: Malware is limited to a few types.", 
    QUESTION_TYPE_TF,
    null,
    "False",
    "obj_Malware")
    );      

test.AddQuestion( new Question ("com.scorm.ZibaSec.interactions.Malware_2",
    "True or False: Humans can help prevent and detect malware.", 
    QUESTION_TYPE_TF,
    null,
    "True",
    "obj_Malware")
    );      

test.AddQuestion( new Question ("com.scorm.ZibaSec.interactions.Malware_3",
    "Which of the following is not part of recovering from a malware infection?", 
    QUESTION_TYPE_CHOICE, 
    new Array("Containment","Eradication","Restoration","Scanning"),
    "Scanning",
    "obj_Malware")
    );      


